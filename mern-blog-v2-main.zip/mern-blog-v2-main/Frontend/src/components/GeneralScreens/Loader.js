import React from 'react';
import '../../Css/Loader.css'
const Loader = () => {
  return (
     <div className="mask">
         <div className="loader"></div>
    </div>

  );
}

export default Loader;